# Opinion formation by ”employed agents” in social networks
 
